using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using DNUContact.Models;

namespace DNUContact.Data
{
    public static class SeedData
    {
        public static async Task Initialize(IServiceProvider serviceProvider)
        {
            using (var scope = serviceProvider.CreateScope())
            {
                var services = scope.ServiceProvider;
                try
                {
                    var context = services.GetRequiredService<ApplicationDbContext>();
                    var userManager = services.GetRequiredService<UserManager<ApplicationUser>>();
                    var roleManager = services.GetRequiredService<RoleManager<IdentityRole>>();

                    // Ensure database is created
                    await context.Database.EnsureCreatedAsync();

                    // Seed roles
                    string[] roles = { "Admin", "CBGV", "SinhVien" };
                    foreach (var role in roles)
                    {
                        if (!await roleManager.RoleExistsAsync(role))
                        {
                            await roleManager.CreateAsync(new IdentityRole(role));
                            Console.WriteLine($"{role} role created!");
                        }
                    }

                    // Seed Admin user
                    if (await userManager.FindByEmailAsync("admin@dnu.edu.vn") == null)
                    {
                        var adminUser = new ApplicationUser
                        {
                            UserName = "admin@dnu.edu.vn",
                            Email = "admin@dnu.edu.vn",
                            FullName = "Nguyễn Văn Admin",
                            EmailConfirmed = true,
                            IsActive = true,
                            IsEmailVerified = true,
                            CreatedAt = DateTime.Now
                        };

                        var result = await userManager.CreateAsync(adminUser, "Admin@123");
                        if (result.Succeeded)
                        {
                            await userManager.AddToRoleAsync(adminUser, "Admin");
                            Console.WriteLine("Admin user created successfully!");
                        }
                    }

                    // Seed CBGV user
                    if (await userManager.FindByEmailAsync("gv01@dnu.edu.vn") == null)
                    {
                        var cbgvUser = new ApplicationUser
                        {
                            UserName = "gv01@dnu.edu.vn",
                            Email = "gv01@dnu.edu.vn",
                            FullName = "Trần Thị Lan",
                            EmailConfirmed = true,
                            IsActive = true,
                            IsEmailVerified = true,
                            CreatedAt = DateTime.Now
                        };

                        var result = await userManager.CreateAsync(cbgvUser, "Cbgv@123");
                        if (result.Succeeded)
                        {
                            await userManager.AddToRoleAsync(cbgvUser, "CBGV");

                            // Create Staff record
                            var staff = new Staff
                            {
                                StaffCode = "GV001",
                                FullName = "Trần Thị Lan",
                                Position = "Giảng viên",
                                Phone = "0123456789",
                                Email = "gv01@dnu.edu.vn",
                                AcademicDegree = "Thạc sĩ",
                                UnitId = 1,
                                UserId = cbgvUser.Id,
                                IsActive = true,
                                CreatedAt = DateTime.Now
                            };
                            context.Staff.Add(staff);

                            Console.WriteLine("CBGV user created successfully!");
                        }
                    }

                    // Seed Student user
                    if (await userManager.FindByEmailAsync("sv01@e.dnu.edu.vn") == null)
                    {
                        var studentUser = new ApplicationUser
                        {
                            UserName = "sv01@e.dnu.edu.vn",
                            Email = "sv01@e.dnu.edu.vn",
                            FullName = "Lê Văn Nam",
                            EmailConfirmed = true,
                            IsActive = true,
                            IsEmailVerified = true,
                            CreatedAt = DateTime.Now
                        };

                        var result = await userManager.CreateAsync(studentUser, "Student@123");
                        if (result.Succeeded)
                        {
                            await userManager.AddToRoleAsync(studentUser, "SinhVien");

                            // Create Student record
                            var student = new Student
                            {
                                StudentCode = "SV2024001",
                                FullName = "Lê Văn Nam",
                                Phone = "0987654321",
                                Email = "sv01@e.dnu.edu.vn",
                                Address = "Hà Nội",
                                ClassName = "CNTT2024A",
                                EnrollmentYear = 2024,
                                UserId = studentUser.Id,
                                IsActive = true,
                                CreatedAt = DateTime.Now
                            };
                            context.Students.Add(student);

                            Console.WriteLine("Student user created successfully!");
                        }
                    }

                    // Seed sample units
                    if (!context.Units.Any())
                    {
                        var units = new List<Unit>
                        {
                            new Unit
                            {
                                UnitCode = "DNU",
                                Name = "Đại học Đại Nam",
                                Address = "Hà Nội",
                                Phone = "024-12345678",
                                Email = "info@dnu.edu.vn",
                                UnitType = "Trường",
                                IsActive = true,
                                CreatedAt = DateTime.Now
                            },
                            new Unit
                            {
                                UnitCode = "CNTT",
                                Name = "Khoa Công nghệ thông tin",
                                Address = "Hà Nội",
                                Phone = "024-12345679",
                                Email = "cntt@dnu.edu.vn",
                                UnitType = "Khoa",
                                ParentUnitId = 1,
                                IsActive = true,
                                CreatedAt = DateTime.Now
                            }
                        };

                        context.Units.AddRange(units);
                    }

                    await context.SaveChangesAsync();
                    Console.WriteLine("Database seeding completed!");
                }
                catch (Exception ex)
                {
                    var logger = services.GetRequiredService<ILogger<Program>>();
                    logger.LogError(ex, "An error occurred seeding the DB.");
                    Console.WriteLine($"Database error: {ex.Message}");
                }
            }
        }
    }
}
