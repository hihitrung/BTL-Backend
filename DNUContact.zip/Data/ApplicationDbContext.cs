using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using DNUContact.Models;

namespace DNUContact.Data
{
    public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<Role> CustomRoles { get; set; }
        public DbSet<Unit> Units { get; set; }
        public DbSet<Staff> Staff { get; set; }
        public DbSet<Student> Students { get; set; }
        public DbSet<ActivityLog> ActivityLogs { get; set; }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);

            // Configure relationships
            builder.Entity<Unit>()
                .HasOne(u => u.ParentUnit)
                .WithMany(u => u.ChildUnits)
                .HasForeignKey(u => u.ParentUnitId)
                .OnDelete(DeleteBehavior.Restrict);

            builder.Entity<Staff>()
                .HasOne(s => s.Unit)
                .WithMany(u => u.Staff)
                .HasForeignKey(s => s.UnitId)
                .OnDelete(DeleteBehavior.Restrict);

            builder.Entity<Staff>()
                .HasOne(s => s.User)
                .WithOne(u => u.Staff)
                .HasForeignKey<Staff>(s => s.UserId)
                .OnDelete(DeleteBehavior.Cascade);

            builder.Entity<Student>()
                .HasOne(s => s.User)
                .WithOne(u => u.Student)
                .HasForeignKey<Student>(s => s.UserId)
                .OnDelete(DeleteBehavior.Cascade);

            builder.Entity<ActivityLog>()
                .HasOne(a => a.User)
                .WithMany()
                .HasForeignKey(a => a.UserId)
                .OnDelete(DeleteBehavior.Cascade);

            // Configure indexes for performance
            builder.Entity<Staff>()
                .HasIndex(s => s.StaffCode)
                .IsUnique();

            builder.Entity<Staff>()
                .HasIndex(s => s.Email)
                .IsUnique();

            builder.Entity<Student>()
                .HasIndex(s => s.StudentCode)
                .IsUnique();

            builder.Entity<Student>()
                .HasIndex(s => s.Email)
                .IsUnique();

            builder.Entity<Unit>()
                .HasIndex(u => u.UnitCode)
                .IsUnique();

            builder.Entity<ActivityLog>()
                .HasIndex(a => a.CreatedAt);

            builder.Entity<ActivityLog>()
                .HasIndex(a => a.UserId);
        }
    }
}
