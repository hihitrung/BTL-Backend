using System.ComponentModel.DataAnnotations;

namespace DNUContact.Models
{
    public class ActivityLog
    {
        public int Id { get; set; }
        
        [Required]
        public string UserId { get; set; } = string.Empty;
        
        [Required]
        public string Action { get; set; } = string.Empty;
        
        public string? Description { get; set; }
        
        public string? EntityType { get; set; }
        
        public int? EntityId { get; set; }
        
        public string? IpAddress { get; set; }
        
        public string? UserAgent { get; set; }
        
        public DateTime CreatedAt { get; set; } = DateTime.Now;
        
        // Navigation property
        public virtual ApplicationUser? User { get; set; }
    }
}
