using System.ComponentModel.DataAnnotations;

namespace DNUContact.Models
{
    public class Unit
    {
        public int UnitId { get; set; }

        [Required]
        [StringLength(10)]
        public string UnitCode { get; set; } = string.Empty;

        [Required]
        [StringLength(200)]
        public string Name { get; set; } = string.Empty;

        [StringLength(500)]
        public string? Address { get; set; }

        [StringLength(255)]
        public string? LogoUrl { get; set; }

        [StringLength(20)]
        public string? Phone { get; set; }

        [StringLength(100)]
        public string? Email { get; set; }

        [StringLength(20)]
        public string? Fax { get; set; }

        [StringLength(50)]
        public string? UnitType { get; set; }

        // Self-referencing relationship
        public int? ParentUnitId { get; set; }
        public virtual Unit? ParentUnit { get; set; }
        public virtual ICollection<Unit> ChildUnits { get; set; } = new List<Unit>();

        // Navigation properties
        public virtual ICollection<Staff> Staff { get; set; } = new List<Staff>();

        public bool IsActive { get; set; } = true;
        public DateTime CreatedAt { get; set; } = DateTime.Now;
        public DateTime? UpdatedAt { get; set; }
    }
}
