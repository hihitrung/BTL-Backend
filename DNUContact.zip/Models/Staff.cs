using System.ComponentModel.DataAnnotations;

namespace DNUContact.Models
{
    public class Staff
    {
        public int StaffId { get; set; }

        [Required]
        [StringLength(20)]
        public string StaffCode { get; set; } = string.Empty;

        [Required]
        [StringLength(100)]
        public string FullName { get; set; } = string.Empty;

        [StringLength(100)]
        public string? Position { get; set; }

        [StringLength(50)]
        public string? AcademicRank { get; set; }

        [StringLength(50)]
        public string? AcademicDegree { get; set; }

        [StringLength(20)]
        public string? Phone { get; set; }

        [StringLength(100)]
        public string? Email { get; set; }

        [StringLength(255)]
        public string? PhotoUrl { get; set; }

        public DateTime? DateOfBirth { get; set; }

        [StringLength(10)]
        public string? Gender { get; set; }

        [StringLength(500)]
        public string? Address { get; set; }

        public int? UnitId { get; set; }
        public virtual Unit? Unit { get; set; }

        [Required]
        public string UserId { get; set; } = string.Empty;
        public virtual ApplicationUser User { get; set; } = null!;

        public bool IsActive { get; set; } = true;
        public DateTime CreatedAt { get; set; } = DateTime.Now;
        public DateTime? UpdatedAt { get; set; }
    }
}
