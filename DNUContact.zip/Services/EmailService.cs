using System.Net;
using System.Net.Mail;

namespace DNUContact.Services
{
    public class EmailService : IEmailService
    {
        private readonly IConfiguration _configuration;
        private readonly ILogger<EmailService> _logger;

        public EmailService(IConfiguration configuration, ILogger<EmailService> logger)
        {
            _configuration = configuration;
            _logger = logger;
        }

        public async Task SendEmailVerificationAsync(string email, string token, string userId)
        {
            var subject = "Xác thực email - DNUContact";
            var verificationLink = $"{GetBaseUrl()}/Account/VerifyEmail?userId={userId}&token={Uri.EscapeDataString(token)}";
            var body = $@"
                <!DOCTYPE html>
                <html>
                <head>
                    <meta charset='utf-8'>
                    <style>
                        body {{ font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; margin: 0; padding: 20px; background-color: #f5f5f5; }}
                        .container {{ max-width: 600px; margin: 0 auto; background: white; border-radius: 10px; padding: 30px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }}
                        .logo {{ text-align: center; margin-bottom: 30px; }}
                        .logo-circle {{ width: 80px; height: 80px; background: linear-gradient(135deg, #F7941D, #FF8C00); border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; color: white; font-size: 2rem; }}
                        h2 {{ color: #333; text-align: center; margin-bottom: 20px; }}
                        p {{ color: #666; line-height: 1.6; margin-bottom: 20px; }}
                        .btn {{ display: inline-block; background: linear-gradient(135deg, #F7941D, #FF8C00); color: white; padding: 12px 30px; text-decoration: none; border-radius: 8px; font-weight: 600; }}
                        .btn:hover {{ background: linear-gradient(135deg, #e6831a, #e6831a); }}
                        .footer {{ margin-top: 30px; padding-top: 20px; border-top: 1px solid #eee; font-size: 0.9rem; color: #999; text-align: center; }}
                    </style>
                </head>
                <body>
                    <div class='container'>
                        <div class='logo'>
                            <div class='logo-circle'>🎓</div>
                        </div>
                        <h2>Xác thực địa chỉ email</h2>
                        <p>Cảm ơn bạn đã đăng ký tài khoản DNUContact!</p>
                        <p>Vui lòng nhấp vào nút bên dưới để xác thực địa chỉ email của bạn:</p>
                        <p style='text-align: center; margin: 30px 0;'>
                            <a href='{verificationLink}' class='btn'>Xác thực email</a>
                        </p>
                        <p>Nếu bạn không thể nhấp vào nút, hãy sao chép và dán URL sau vào trình duyệt:</p>
                        <p style='word-break: break-all; background: #f8f9fa; padding: 10px; border-radius: 5px; font-family: monospace;'>{verificationLink}</p>
                        <div class='footer'>
                            <p>Email này được gửi tự động từ hệ thống DNUContact.<br>
                            Vui lòng không trả lời email này.</p>
                        </div>
                    </div>
                </body>
                </html>";

            await SendEmailAsync(email, subject, body);
        }

        public async Task SendPasswordResetAsync(string email, string token)
        {
            var subject = "Đặt lại mật khẩu - DNUContact";
            var resetLink = $"{GetBaseUrl()}/Account/ResetPassword?email={email}&token={Uri.EscapeDataString(token)}";
            var body = $@"
                <!DOCTYPE html>
                <html>
                <head>
                    <meta charset='utf-8'>
                    <style>
                        body {{ font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; margin: 0; padding: 20px; background-color: #f5f5f5; }}
                        .container {{ max-width: 600px; margin: 0 auto; background: white; border-radius: 10px; padding: 30px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }}
                        .logo {{ text-align: center; margin-bottom: 30px; }}
                        .logo-circle {{ width: 80px; height: 80px; background: linear-gradient(135deg, #F7941D, #FF8C00); border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; color: white; font-size: 2rem; }}
                        h2 {{ color: #333; text-align: center; margin-bottom: 20px; }}
                        p {{ color: #666; line-height: 1.6; margin-bottom: 20px; }}
                        .btn {{ display: inline-block; background: linear-gradient(135deg, #007bff, #0056b3); color: white; padding: 12px 30px; text-decoration: none; border-radius: 8px; font-weight: 600; }}
                        .warning {{ background: #fff3cd; border: 1px solid #ffeaa7; padding: 15px; border-radius: 5px; color: #856404; margin: 20px 0; }}
                        .footer {{ margin-top: 30px; padding-top: 20px; border-top: 1px solid #eee; font-size: 0.9rem; color: #999; text-align: center; }}
                    </style>
                </head>
                <body>
                    <div class='container'>
                        <div class='logo'>
                            <div class='logo-circle'>🔒</div>
                        </div>
                        <h2>Đặt lại mật khẩu</h2>
                        <p>Bạn đã yêu cầu đặt lại mật khẩu cho tài khoản DNUContact.</p>
                        <p>Nhấp vào nút bên dưới để đặt lại mật khẩu:</p>
                        <p style='text-align: center; margin: 30px 0;'>
                            <a href='{resetLink}' class='btn'>Đặt lại mật khẩu</a>
                        </p>
                        <div class='warning'>
                            <strong>⚠️ Lưu ý:</strong> Liên kết này sẽ hết hạn sau 24 giờ vì lý do bảo mật.
                        </div>
                        <p>Nếu bạn không yêu cầu đặt lại mật khẩu, vui lòng bỏ qua email này. Tài khoản của bạn vẫn an toàn.</p>
                        <div class='footer'>
                            <p>Email này được gửi tự động từ hệ thống DNUContact.<br>
                            Vui lòng không trả lời email này.</p>
                        </div>
                    </div>
                </body>
                </html>";

            await SendEmailAsync(email, subject, body);
        }

        public async Task SendWelcomeEmailAsync(string email, string fullName)
        {
            var subject = "Chào mừng đến với DNUContact";
            var body = $@"
                <!DOCTYPE html>
                <html>
                <head>
                    <meta charset='utf-8'>
                    <style>
                        body {{ font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; margin: 0; padding: 20px; background-color: #f5f5f5; }}
                        .container {{ max-width: 600px; margin: 0 auto; background: white; border-radius: 10px; padding: 30px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }}
                        .logo {{ text-align: center; margin-bottom: 30px; }}
                        .logo-circle {{ width: 80px; height: 80px; background: linear-gradient(135deg, #28a745, #20c997); border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; color: white; font-size: 2rem; }}
                        h2 {{ color: #333; text-align: center; margin-bottom: 20px; }}
                        p {{ color: #666; line-height: 1.6; margin-bottom: 20px; }}
                        .features {{ background: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0; }}
                        .features ul {{ margin: 0; padding-left: 20px; }}
                        .features li {{ margin-bottom: 8px; }}
                        .footer {{ margin-top: 30px; padding-top: 20px; border-top: 1px solid #eee; font-size: 0.9rem; color: #999; text-align: center; }}
                    </style>
                </head>
                <body>
                    <div class='container'>
                        <div class='logo'>
                            <div class='logo-circle'>🎉</div>
                        </div>
                        <h2>Chào mừng {fullName}!</h2>
                        <p>Tài khoản DNUContact của bạn đã được tạo thành công và sẵn sàng sử dụng.</p>
                        
                        <div class='features'>
                            <p><strong>Bạn có thể sử dụng các tính năng sau:</strong></p>
                            <ul>
                                <li>Xem danh bạ đơn vị của trường</li>
                                <li>Tìm kiếm thông tin cán bộ giảng viên</li>
                                <li>Kết nối với sinh viên cùng lớp</li>
                                <li>Cập nhật thông tin cá nhân</li>
                            </ul>
                        </div>
                        
                        <p>Chúc bạn có trải nghiệm tốt với DNUContact!</p>
                        
                        <div class='footer'>
                            <p>Trân trọng,<br>
                            Đội ngũ phát triển DNUContact</p>
                        </div>
                    </div>
                </body>
                </html>";

            await SendEmailAsync(email, subject, body);
        }

        private async Task SendEmailAsync(string to, string subject, string body)
        {
            try
            {
                var smtpSettings = _configuration.GetSection("SmtpSettings");
                
                // Check if SMTP is configured
                if (string.IsNullOrEmpty(smtpSettings["Host"]) || string.IsNullOrEmpty(smtpSettings["Username"]))
                {
                    _logger.LogWarning("SMTP not configured. Email would be sent to {Email} with subject: {Subject}", to, subject);
                    return;
                }

                using var client = new SmtpClient(smtpSettings["Host"], int.Parse(smtpSettings["Port"]!))
                {
                    Credentials = new NetworkCredential(smtpSettings["Username"], smtpSettings["Password"]),
                    EnableSsl = bool.Parse(smtpSettings["EnableSsl"]!)
                };

                var mailMessage = new MailMessage
                {
                    From = new MailAddress(smtpSettings["FromEmail"]!, smtpSettings["FromName"]),
                    Subject = subject,
                    Body = body,
                    IsBodyHtml = true
                };
                
                mailMessage.To.Add(to);
                await client.SendMailAsync(mailMessage);
                
                _logger.LogInformation("Email sent successfully to {Email}", to);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to send email to {Email}", to);
                // Don't throw in production - just log the error
            }
        }

        private string GetBaseUrl()
        {
            // In production, this should come from configuration
            return "https://localhost:5001";
        }
    }
}
