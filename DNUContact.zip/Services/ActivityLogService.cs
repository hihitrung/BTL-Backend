using DNUContact.Data;
using DNUContact.Models;
using Microsoft.EntityFrameworkCore;

namespace DNUContact.Services
{
    public interface IActivityLogService
    {
        Task LogActivityAsync(string userId, string action, string? description = null, string? entityType = null, int? entityId = null);
        Task<List<ActivityLog>> GetRecentActivitiesAsync(int count = 10);
        Task<List<ActivityLog>> GetUserActivitiesAsync(string userId, int count = 20);
    }

    public class ActivityLogService : IActivityLogService
    {
        private readonly ApplicationDbContext _context;
        private readonly IHttpContextAccessor _httpContextAccessor;

        public ActivityLogService(ApplicationDbContext context, IHttpContextAccessor httpContextAccessor)
        {
            _context = context;
            _httpContextAccessor = httpContextAccessor;
        }

        public async Task LogActivityAsync(string userId, string action, string? description = null, string? entityType = null, int? entityId = null)
        {
            try
            {
                var httpContext = _httpContextAccessor.HttpContext;
                
                var activityLog = new ActivityLog
                {
                    UserId = userId,
                    Action = action,
                    Description = description,
                    EntityType = entityType,
                    EntityId = entityId,
                    IpAddress = httpContext?.Connection?.RemoteIpAddress?.ToString(),
                    UserAgent = httpContext?.Request?.Headers["User-Agent"].ToString(),
                    CreatedAt = DateTime.Now
                };

                _context.ActivityLogs.Add(activityLog);
                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                // Log error but don't throw to avoid breaking the main functionality
                Console.WriteLine($"Error logging activity: {ex.Message}");
            }
        }

        public async Task<List<ActivityLog>> GetRecentActivitiesAsync(int count = 10)
        {
            try
            {
                return await _context.ActivityLogs
                    .Include(a => a.User)
                    .OrderByDescending(a => a.CreatedAt)
                    .Take(count)
                    .ToListAsync();
            }
            catch
            {
                return new List<ActivityLog>();
            }
        }

        public async Task<List<ActivityLog>> GetUserActivitiesAsync(string userId, int count = 20)
        {
            try
            {
                return await _context.ActivityLogs
                    .Where(a => a.UserId == userId)
                    .OrderByDescending(a => a.CreatedAt)
                    .Take(count)
                    .ToListAsync();
            }
            catch
            {
                return new List<ActivityLog>();
            }
        }
    }
}
