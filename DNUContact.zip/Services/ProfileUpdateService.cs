using DNUContact.Models;
using DNUContact.Data;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

namespace DNUContact.Services
{
    public interface IProfileUpdateService
    {
        Task<bool> UpdateProfileAsync(ApplicationUser user, string? phoneNumber, string? address, IFormFile? avatar);
        Task<string?> UploadAvatarAsync(IFormFile avatar, string userId);
    }

    public class ProfileUpdateService : IProfileUpdateService
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly IWebHostEnvironment _environment;

        public ProfileUpdateService(
            ApplicationDbContext context,
            UserManager<ApplicationUser> userManager,
            IWebHostEnvironment environment)
        {
            _context = context;
            _userManager = userManager;
            _environment = environment;
        }

        public async Task<bool> UpdateProfileAsync(ApplicationUser user, string? phoneNumber, string? address, IFormFile? avatar)
        {
            using var transaction = await _context.Database.BeginTransactionAsync();
            try
            {
                // Upload avatar if provided
                if (avatar != null && avatar.Length > 0)
                {
                    var avatarUrl = await UploadAvatarAsync(avatar, user.Id);
                    if (avatarUrl != null)
                    {
                        user.PhotoUrl = avatarUrl;
                    }
                }

                // Update phone number if provided
                if (!string.IsNullOrEmpty(phoneNumber))
                {
                    user.PhoneNumber = phoneNumber;
                }

                user.UpdatedAt = DateTime.Now;

                // Update user in Identity
                var result = await _userManager.UpdateAsync(user);
                if (!result.Succeeded)
                {
                    await transaction.RollbackAsync();
                    return false;
                }

                // Update role-specific tables
                var roles = await _userManager.GetRolesAsync(user);
                
                if (roles.Contains("CBGV"))
                {
                    var staff = await _context.Staff.FirstOrDefaultAsync(s => s.UserId == user.Id);
                    if (staff != null)
                    {
                        if (!string.IsNullOrEmpty(phoneNumber))
                            staff.Phone = phoneNumber;
                        if (user.PhotoUrl != null)
                            staff.PhotoUrl = user.PhotoUrl;
                        staff.UpdatedAt = DateTime.Now;
                        _context.Staff.Update(staff);
                    }
                }
                else if (roles.Contains("SinhVien"))
                {
                    var student = await _context.Students.FirstOrDefaultAsync(s => s.UserId == user.Id);
                    if (student != null)
                    {
                        if (!string.IsNullOrEmpty(phoneNumber))
                            student.Phone = phoneNumber;
                        if (!string.IsNullOrEmpty(address))
                            student.Address = address;
                        if (user.PhotoUrl != null)
                            student.PhotoUrl = user.PhotoUrl;
                        student.UpdatedAt = DateTime.Now;
                        _context.Students.Update(student);
                    }
                }

                await _context.SaveChangesAsync();
                await transaction.CommitAsync();
                return true;
            }
            catch
            {
                await transaction.RollbackAsync();
                return false;
            }
        }

        public async Task<string?> UploadAvatarAsync(IFormFile avatar, string userId)
        {
            try
            {
                // Validate file
                var allowedExtensions = new[] { ".jpg", ".jpeg", ".png", ".gif" };
                var extension = Path.GetExtension(avatar.FileName).ToLowerInvariant();
                
                if (!allowedExtensions.Contains(extension))
                {
                    return null;
                }

                if (avatar.Length > 5 * 1024 * 1024) // 5MB limit
                {
                    return null;
                }

                // Create upload directory
                var uploadsFolder = Path.Combine(_environment.WebRootPath, "uploads", "avatars");
                Directory.CreateDirectory(uploadsFolder);
                
                // Generate unique filename
                var fileName = $"{userId}_{Guid.NewGuid()}{extension}";
                var filePath = Path.Combine(uploadsFolder, fileName);
                
                // Save file
                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    await avatar.CopyToAsync(stream);
                }
                
                return $"/uploads/avatars/{fileName}";
            }
            catch
            {
                return null;
            }
        }
    }
}
