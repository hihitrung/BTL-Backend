using System.Text.RegularExpressions;

namespace DNUContact.Services
{
    public static class EmailDomainService
    {
        // Exact domains as specified: @DNU.edu.vn for CBGV, @e.DNU.edu.vn for Students
        private static readonly Dictionary<string, string> DomainRoleMapping = new()
        {
            { "dnu.edu.vn", "CBGV" },
            { "e.dnu.edu.vn", "SinhVien" }
        };

        public static bool IsValidDomainEmail(string email)
        {
            if (string.IsNullOrEmpty(email))
                return false;

            var emailLower = email.ToLowerInvariant();
            
            // Check if email matches any of the allowed domains
            return DomainRoleMapping.Keys.Any(domain => emailLower.EndsWith($"@{domain}"));
        }

        public static string GetRoleFromEmail(string email)
        {
            if (string.IsNullOrEmpty(email))
                return "User";

            var emailLower = email.ToLowerInvariant();
            
            foreach (var kvp in DomainRoleMapping)
            {
                if (emailLower.EndsWith($"@{kvp.Key}"))
                {
                    return kvp.Value;
                }
            }
            
            return "User";
        }

        public static string GetDomainFromEmail(string email)
        {
            if (string.IsNullOrEmpty(email))
                return string.Empty;

            var atIndex = email.LastIndexOf('@');
            if (atIndex == -1 || atIndex == email.Length - 1)
                return string.Empty;

            return email.Substring(atIndex + 1).ToLowerInvariant();
        }

        public static bool IsStaffEmail(string email)
        {
            return GetRoleFromEmail(email) == "CBGV";
        }

        public static bool IsStudentEmail(string email)
        {
            return GetRoleFromEmail(email) == "SinhVien";
        }
    }
}
