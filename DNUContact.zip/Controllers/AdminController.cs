using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using DNUContact.Models;
using DNUContact.Data;
using DNUContact.Services;
using System.Linq;
using System.Threading.Tasks;

namespace DNUContact.Controllers
{
    [Authorize(Roles = "Admin")]
    public class AdminController : Controller
    {
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly ApplicationDbContext _context;
        private readonly IActivityLogService _activityLogService;

        public AdminController(
            UserManager<ApplicationUser> userManager, 
            ApplicationDbContext context,
            IActivityLogService activityLogService)
        {
            _userManager = userManager;
            _context = context;
            _activityLogService = activityLogService;
        }

        public async Task<IActionResult> Dashboard()
        {
            // Real-time statistics
            ViewBag.TotalUsers = await _userManager.Users.CountAsync();
            ViewBag.TotalStaff = await _context.Staff.CountAsync();
            ViewBag.TotalStudents = await _context.Students.CountAsync();
            ViewBag.TotalUnits = await _context.Units.CountAsync();
            ViewBag.ActiveUsers = await _userManager.Users.Where(u => u.IsActive).CountAsync();
            ViewBag.PendingUsers = await _userManager.Users.Where(u => !u.IsEmailVerified).CountAsync();
            
            // Recent activities
            try
            {
                var recentActivities = await _activityLogService.GetRecentActivitiesAsync(10);
                ViewBag.RecentActivities = recentActivities;
            }
            catch
            {
                ViewBag.RecentActivities = new List<ActivityLog>();
            }

            return View();
        }

        public async Task<IActionResult> Users(string search, string role, int page = 1)
        {
            var query = _userManager.Users.AsQueryable();

            // Apply search filter
            if (!string.IsNullOrEmpty(search))
            {
                query = query.Where(u => u.FullName.Contains(search) || u.Email.Contains(search));
            }

            // Apply role filter
            if (!string.IsNullOrEmpty(role))
            {
                var usersInRole = await _userManager.GetUsersInRoleAsync(role);
                var userIds = usersInRole.Select(u => u.Id).ToList();
                query = query.Where(u => userIds.Contains(u.Id));
            }

            var totalCount = await query.CountAsync();
            var pageSize = 10;
            var users = await query
                .OrderByDescending(u => u.CreatedAt)
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();

            // Get roles for each user
            var usersWithRoles = new List<(ApplicationUser User, string Role)>();
            foreach (var user in users)
            {
                var userRoles = await _userManager.GetRolesAsync(user);
                usersWithRoles.Add((user, userRoles.FirstOrDefault() ?? "User"));
            }

            ViewBag.UsersWithRoles = usersWithRoles;
            ViewBag.Search = search;
            ViewBag.Role = role;
            ViewBag.CurrentPage = page;
            ViewBag.TotalPages = (int)Math.Ceiling(totalCount / (double)pageSize);

            return View();
        }

        [HttpGet]
        public async Task<IActionResult> UserEdit(string id)
        {
            if (string.IsNullOrEmpty(id))
            {
                ViewBag.Units = await _context.Units.OrderBy(u => u.Name).ToListAsync();
                return View(new ApplicationUser());
            }

            var user = await _userManager.FindByIdAsync(id);
            if (user == null)
            {
                return NotFound();
            }

            var roles = await _userManager.GetRolesAsync(user);
            ViewBag.UserRole = roles.FirstOrDefault();
            ViewBag.Units = await _context.Units.OrderBy(u => u.Name).ToListAsync();

            // Get current unit assignment
            if (roles.Contains("CBGV"))
            {
                var staff = await _context.Staff.FirstOrDefaultAsync(s => s.UserId == user.Id);
                ViewBag.CurrentUnitId = staff?.UnitId;
            }
            else if (roles.Contains("SinhVien"))
            {
                var student = await _context.Students.FirstOrDefaultAsync(s => s.UserId == user.Id);
                ViewBag.CurrentUnitId = student?.UnitId;
            }

            return View(user);
        }

        [HttpPost]
        public async Task<IActionResult> UserEdit(ApplicationUser model, string role, bool IsActive, bool IsEmailVerified, int? unitId)
        {
            if (string.IsNullOrEmpty(model.Id))
            {
                // Create new user
                var newUser = new ApplicationUser
                {
                    UserName = model.Email,
                    Email = model.Email,
                    FullName = model.FullName,
                    PhoneNumber = model.PhoneNumber,
                    IsEmailVerified = IsEmailVerified,
                    IsActive = IsActive,
                    CreatedAt = DateTime.Now,
                    PhotoUrl = "/images/default-avatar.png"
                };

                var result = await _userManager.CreateAsync(newUser, "TempPassword@123");
                if (result.Succeeded)
                {
                    await _userManager.AddToRoleAsync(newUser, role);

                    // Create Staff or Student record based on role
                    if (role == "CBGV" && unitId.HasValue)
                    {
                        var staff = new Staff
                        {
                            UserId = newUser.Id,
                            StaffCode = $"CB{DateTime.Now:yyyyMMddHHmmss}",
                            FullName = newUser.FullName,
                            Email = newUser.Email,
                            Phone = newUser.PhoneNumber,
                            UnitId = unitId.Value,
                            Position = "Giảng viên",
                            CreatedAt = DateTime.Now,
                            PhotoUrl = "/images/default-avatar.png"
                        };
                        _context.Staff.Add(staff);
                    }
                    else if (role == "SinhVien" && unitId.HasValue)
                    {
                        var student = new Student
                        {
                            UserId = newUser.Id,
                            StudentCode = $"SV{DateTime.Now:yyyyMMddHHmmss}",
                            FullName = newUser.FullName,
                            Email = newUser.Email,
                            Phone = newUser.PhoneNumber,
                            UnitId = unitId.Value,
                            ClassName = "Chưa phân lớp",
                            CreatedAt = DateTime.Now,
                            PhotoUrl = "/images/default-avatar.png"
                        };
                        _context.Students.Add(student);
                    }

                    await _context.SaveChangesAsync();
                    await _activityLogService.LogActivityAsync(newUser.Id, "USER_CREATED", $"Admin tạo người dùng mới: {newUser.FullName}");
                    TempData["Success"] = "Tạo người dùng thành công!";
                    return RedirectToAction("Users");
                }

                foreach (var error in result.Errors)
                {
                    ModelState.AddModelError("", error.Description);
                }
            }
            else
            {
                // Update existing user
                var user = await _userManager.FindByIdAsync(model.Id);
                if (user != null)
                {
                    user.FullName = model.FullName;
                    user.PhoneNumber = model.PhoneNumber;
                    user.IsActive = IsActive;
                    user.IsEmailVerified = IsEmailVerified;
                    user.UpdatedAt = DateTime.Now;

                    var result = await _userManager.UpdateAsync(user);
                    if (result.Succeeded)
                    {
                        // Update role if changed
                        var currentRoles = await _userManager.GetRolesAsync(user);
                        if (!currentRoles.Contains(role))
                        {
                            await _userManager.RemoveFromRolesAsync(user, currentRoles);
                            await _userManager.AddToRoleAsync(user, role);
                        }

                        // Update Staff or Student unit assignment
                        if (role == "CBGV" && unitId.HasValue)
                        {
                            var staff = await _context.Staff.FirstOrDefaultAsync(s => s.UserId == user.Id);
                            if (staff != null)
                            {
                                staff.UnitId = unitId.Value;
                                staff.UpdatedAt = DateTime.Now;
                                _context.Staff.Update(staff);
                            }
                        }
                        else if (role == "SinhVien" && unitId.HasValue)
                        {
                            var student = await _context.Students.FirstOrDefaultAsync(s => s.UserId == user.Id);
                            if (student != null)
                            {
                                student.UnitId = unitId.Value;
                                student.UpdatedAt = DateTime.Now;
                                _context.Students.Update(student);
                            }
                        }

                        await _context.SaveChangesAsync();
                        await _activityLogService.LogActivityAsync(user.Id, "USER_UPDATED", $"Admin cập nhật thông tin người dùng: {user.FullName}");
                        TempData["Success"] = "Cập nhật người dùng thành công!";
                        return RedirectToAction("Users");
                    }
                }
            }

            ViewBag.UserRole = role;
            ViewBag.Units = await _context.Units.OrderBy(u => u.Name).ToListAsync();
            return View(model);
        }

        [HttpPost]
        public async Task<IActionResult> DeleteUser(string id)
        {
            var user = await _userManager.FindByIdAsync(id);
            if (user != null)
            {
                var roles = await _userManager.GetRolesAsync(user);
                if (!roles.Contains("Admin")) // Prevent deleting admin users
                {
                    var result = await _userManager.DeleteAsync(user);
                    if (result.Succeeded)
                    {
                        await _activityLogService.LogActivityAsync(user.Id, "USER_DELETED", $"Admin xóa người dùng: {user.FullName}");
                        TempData["Success"] = "Xóa người dùng thành công!";
                    }
                    else
                    {
                        TempData["Error"] = "Có lỗi xảy ra khi xóa người dùng!";
                    }
                }
                else
                {
                    TempData["Error"] = "Không thể xóa tài khoản Admin!";
                }
            }

            return RedirectToAction("Users");
        }

        // Password Reset by Admin
        [HttpGet]
        public async Task<IActionResult> ResetUserPassword(string id)
        {
            var user = await _userManager.FindByIdAsync(id);
            if (user == null)
            {
                return NotFound();
            }

            ViewBag.User = user;
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> ResetUserPassword(string id, string newPassword, string confirmPassword)
        {
            if (newPassword != confirmPassword)
            {
                ViewBag.Error = "Mật khẩu xác nhận không khớp";
                var user = await _userManager.FindByIdAsync(id);
                ViewBag.User = user;
                return View();
            }

            var targetUser = await _userManager.FindByIdAsync(id);
            if (targetUser != null)
            {
                var token = await _userManager.GeneratePasswordResetTokenAsync(targetUser);
                var result = await _userManager.ResetPasswordAsync(targetUser, token, newPassword);

                if (result.Succeeded)
                {
                    await _activityLogService.LogActivityAsync(targetUser.Id, "PASSWORD_RESET_BY_ADMIN", "Admin đặt lại mật khẩu");
                    TempData["Success"] = "Đặt lại mật khẩu thành công!";
                    return RedirectToAction("Users");
                }

                ViewBag.Error = string.Join(", ", result.Errors.Select(e => e.Description));
            }

            ViewBag.User = targetUser;
            return View();
        }

        public async Task<IActionResult> Units(string search, string unitType, int page = 1)
        {
            var query = _context.Units.Include(u => u.ParentUnit).AsQueryable();

            if (!string.IsNullOrEmpty(search))
            {
                query = query.Where(u => u.Name.Contains(search) || u.UnitCode.Contains(search));
            }

            if (!string.IsNullOrEmpty(unitType))
            {
                query = query.Where(u => u.UnitType == unitType);
            }

            var totalCount = await query.CountAsync();
            var pageSize = 10;
            var units = await query
                .OrderBy(u => u.Name)
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();

            ViewBag.Search = search;
            ViewBag.UnitType = unitType;
            ViewBag.CurrentPage = page;
            ViewBag.TotalPages = (int)Math.Ceiling(totalCount / (double)pageSize);
            ViewBag.UnitTypes = await _context.Units
                .Where(u => !string.IsNullOrEmpty(u.UnitType))
                .Select(u => u.UnitType)
                .Distinct()
                .ToListAsync();

            return View(units);
        }

        [HttpGet]
        public async Task<IActionResult> UnitEdit(int? id)
        {
            Unit unit;
            if (id.HasValue)
            {
                unit = await _context.Units.FindAsync(id.Value);
                if (unit == null)
                {
                    return NotFound();
                }
            }
            else
            {
                unit = new Unit();
            }

            ViewBag.ParentUnits = await _context.Units
                .Where(u => !id.HasValue || u.UnitId != id.Value)
                .OrderBy(u => u.Name)
                .ToListAsync();

            return View(unit);
        }

        [HttpPost]
        public async Task<IActionResult> UnitEdit(Unit model)
        {
            if (ModelState.IsValid)
            {
                if (model.UnitId == 0)
                {
                    // Create new unit
                    model.CreatedAt = DateTime.Now;
                    _context.Units.Add(model);
                    TempData["Success"] = "Tạo đơn vị thành công!";
                }
                else
                {
                    // Update existing unit
                    model.UpdatedAt = DateTime.Now;
                    _context.Units.Update(model);
                    TempData["Success"] = "Cập nhật đơn vị thành công!";
                }

                await _context.SaveChangesAsync();
                return RedirectToAction("Units");
            }

            ViewBag.ParentUnits = await _context.Units
                .Where(u => u.UnitId != model.UnitId)
                .OrderBy(u => u.Name)
                .ToListAsync();

            return View(model);
        }

        [HttpPost]
        public async Task<IActionResult> DeleteUnit(int id)
        {
            var unit = await _context.Units.FindAsync(id);
            if (unit != null)
            {
                _context.Units.Remove(unit);
                await _context.SaveChangesAsync();
                TempData["Success"] = "Xóa đơn vị thành công!";
            }

            return RedirectToAction("Units");
        }

        public async Task<IActionResult> Statistics()
        {
            // Real-time statistics
            ViewBag.TotalUsers = await _userManager.Users.CountAsync();
            ViewBag.TotalStaff = await _context.Staff.CountAsync();
            ViewBag.TotalStudents = await _context.Students.CountAsync();
            ViewBag.TotalUnits = await _context.Units.CountAsync();
            ViewBag.ActiveUsers = await _userManager.Users.Where(u => u.IsActive).CountAsync();
            ViewBag.PendingUsers = await _userManager.Users.Where(u => !u.IsEmailVerified).CountAsync();
            
            // Role statistics
            var adminUsers = await _userManager.GetUsersInRoleAsync("Admin");
            var staffUsers = await _userManager.GetUsersInRoleAsync("CBGV");
            var studentUsers = await _userManager.GetUsersInRoleAsync("SinhVien");
            
            ViewBag.TotalAdmins = adminUsers.Count;
            ViewBag.TotalStaffUsers = staffUsers.Count;
            ViewBag.TotalStudentUsers = studentUsers.Count;

            return View();
        }

        public IActionResult Settings()
        {
            // Load current settings
            ViewBag.SystemName = "DNUContact";
            ViewBag.SchoolName = "Đại học Đại Nam";
            ViewBag.AdminEmail = "admin@dnu.edu.vn";
            ViewBag.AllowRegistration = true;
            ViewBag.RequireEmailVerification = false; // Changed to admin approval
            ViewBag.MaxFileSize = 10;
            ViewBag.SessionTimeout = 60;
            
            return View();
        }

        [HttpPost]
        public IActionResult SaveSettings(string systemName, string schoolName, string adminEmail, 
            bool allowRegistration, bool requireEmailVerification, int maxFileSize, int sessionTimeout)
        {
            // Save settings logic here (could be in database or configuration)
            TempData["Success"] = "Cài đặt đã được lưu thành công!";
            return RedirectToAction("Settings");
        }

        public async Task<IActionResult> ActivityLogs(int page = 1)
        {
            try
            {
                var activities = await _activityLogService.GetRecentActivitiesAsync(100);
                var totalCount = activities.Count;
                
                // Take only the items for current page
                var pagedActivities = activities.Skip((page - 1) * 20).Take(20).ToList();
                
                ViewBag.CurrentPage = page;
                ViewBag.TotalPages = (int)Math.Ceiling(totalCount / 20.0);
                
                return View(pagedActivities);
            }
            catch
            {
                return View(new List<ActivityLog>());
            }
        }

        // API endpoint for real-time data
        [HttpGet]
        public async Task<IActionResult> GetStatistics()
        {
            var stats = new
            {
                TotalUsers = await _userManager.Users.CountAsync(),
                TotalStaff = await _context.Staff.CountAsync(),
                TotalStudents = await _context.Students.CountAsync(),
                TotalUnits = await _context.Units.CountAsync(),
                ActiveUsers = await _userManager.Users.Where(u => u.IsActive).CountAsync(),
                PendingUsers = await _userManager.Users.Where(u => !u.IsEmailVerified).CountAsync()
            };

            return Json(stats);
        }
    }
}
