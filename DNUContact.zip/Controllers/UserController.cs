using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using DNUContact.Models;
using DNUContact.Data;
using DNUContact.Services;
using System.Linq;

namespace DNUContact.Controllers
{
    [Authorize]
    public class UserController : Controller
    {
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly SignInManager<ApplicationUser> _signInManager;
        private readonly ApplicationDbContext _context;
        private readonly IActivityLogService _activityLogService;

        public UserController(
            UserManager<ApplicationUser> userManager, 
            SignInManager<ApplicationUser> signInManager,
            ApplicationDbContext context,
            IActivityLogService activityLogService)
        {
            _userManager = userManager;
            _signInManager = signInManager;
            _context = context;
            _activityLogService = activityLogService;
        }

        private string GetDefaultAvatar()
        {
            return "/images/default-avatar.png";
        }

        public async Task<IActionResult> Dashboard()
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null)
            {
                return RedirectToAction("Login", "Account");
            }

            await _activityLogService.LogActivityAsync(user.Id, "VIEW_DASHBOARD", "Truy cập trang chủ");

            var roles = await _userManager.GetRolesAsync(user);
            var userRole = roles?.FirstOrDefault() ?? "User";
            
            // Get detailed user information based on role
            ViewBag.UserRole = userRole;
            ViewBag.UserName = user.FullName ?? user.UserName ?? "";
            ViewBag.UserEmail = user.Email;
            ViewBag.UserAvatar = user.PhotoUrl ?? GetDefaultAvatar();

            // Get role-specific information
            if (roles != null && roles.Contains("CBGV"))
            {
                var staff = await _context.Staff
                    .Include(s => s.Unit)
                    .FirstOrDefaultAsync(s => s.UserId == user.Id);
                
                if (staff != null)
                {
                    ViewBag.StaffInfo = staff;
                    ViewBag.UserName = staff.FullName;
                    ViewBag.UserAvatar = staff.PhotoUrl ?? GetDefaultAvatar();
                    ViewBag.UserPosition = staff.Position;
                    ViewBag.UserUnit = staff.Unit?.Name;
                }
            }
            else if (roles != null && roles.Contains("SinhVien"))
            {
                var student = await _context.Students
                    .FirstOrDefaultAsync(s => s.UserId == user.Id);
                
                if (student != null)
                {
                    ViewBag.StudentInfo = student;
                    ViewBag.UserName = student.FullName;
                    ViewBag.UserAvatar = student.PhotoUrl ?? GetDefaultAvatar();
                    ViewBag.UserClass = student.ClassName;
                    ViewBag.UserMajor = student.Major;
                }
            }
            
            // Get statistics
            ViewBag.TotalUnits = await _context.Units.CountAsync();
            ViewBag.TotalStaff = await _context.Staff.CountAsync();
            ViewBag.TotalStudents = await _context.Students.CountAsync();
            
            // Role-based access permissions
            ViewBag.CanViewStaff = roles != null && (roles.Contains("CBGV") || roles.Contains("Admin"));
            ViewBag.CanViewStudents = true; // All users can view students (with restrictions)
            ViewBag.CanViewUnits = true; // All users can view units
            
            return View();
        }

        public async Task<IActionResult> Profile()
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null)
            {
                return RedirectToAction("Login", "Account");
            }

            await _activityLogService.LogActivityAsync(user.Id, "VIEW_PROFILE", "Xem hồ sơ cá nhân");

            var roles = await _userManager.GetRolesAsync(user);
            ViewBag.UserRole = roles?.FirstOrDefault() ?? "User";
            ViewBag.UserName = user.FullName ?? user.UserName ?? "";
            ViewBag.UserAvatar = user.PhotoUrl ?? GetDefaultAvatar();

            // Get statistics
            ViewBag.TotalUnits = await _context.Units.CountAsync();
            ViewBag.TotalStaff = await _context.Staff.CountAsync();
            ViewBag.TotalStudents = await _context.Students.CountAsync();
            ViewBag.CanViewStaff = roles != null && (roles.Contains("CBGV") || roles.Contains("Admin"));

            // Load additional profile data based on role
            if (roles != null && roles.Contains("CBGV"))
            {
                var staff = await _context.Staff
                    .Include(s => s.Unit)
                    .FirstOrDefaultAsync(s => s.UserId == user.Id);
                ViewBag.StaffInfo = staff;
                if (staff != null)
                {
                    ViewBag.UserName = staff.FullName;
                    ViewBag.UserAvatar = staff.PhotoUrl ?? GetDefaultAvatar();
                    ViewBag.UserPosition = staff.Position;
                    ViewBag.UserUnit = staff.Unit?.Name;
                }
            }
            else if (roles != null && roles.Contains("SinhVien"))
            {
                var student = await _context.Students
                    .FirstOrDefaultAsync(s => s.UserId == user.Id);
                ViewBag.StudentInfo = student;
                if (student != null)
                {
                    ViewBag.UserName = student.FullName;
                    ViewBag.UserAvatar = student.PhotoUrl ?? GetDefaultAvatar();
                    ViewBag.UserClass = student.ClassName;
                    ViewBag.UserMajor = student.Major;
                }
            }

            return View(user);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> UpdateProfile(string? phoneNumber, string? address, IFormFile? avatar)
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null)
            {
                return NotFound();
            }

            // Server-side validation
            if (!string.IsNullOrEmpty(phoneNumber))
            {
                var phoneRegex = new System.Text.RegularExpressions.Regex(@"^[0-9+\-\s()]{10,15}$");
                if (!phoneRegex.IsMatch(phoneNumber))
                {
                    TempData["Error"] = "Số điện thoại không hợp lệ.";
                    return RedirectToAction("Profile");
                }
            }

            if (avatar != null && avatar.Length > 0)
            {
                // Validate file size (5MB)
                if (avatar.Length > 5 * 1024 * 1024)
                {
                    TempData["Error"] = "Kích thước file không được vượt quá 5MB.";
                    return RedirectToAction("Profile");
                }

                // Validate file type
                var allowedExtensions = new[] { ".jpg", ".jpeg", ".png", ".gif" };
                var extension = Path.GetExtension(avatar.FileName).ToLowerInvariant();
                if (!allowedExtensions.Contains(extension))
                {
                    TempData["Error"] = "Chỉ chấp nhận file ảnh (JPG, PNG, GIF).";
                    return RedirectToAction("Profile");
                }
            }

            var roles = await _userManager.GetRolesAsync(user);

            // Check if student is trying to update address
            if (!string.IsNullOrEmpty(address) && (roles == null || !roles.Contains("SinhVien")))
            {
                TempData["Error"] = "Chỉ sinh viên được phép cập nhật địa chỉ.";
                return RedirectToAction("Profile");
            }

            using var transaction = await _context.Database.BeginTransactionAsync();
            try
            {
                // Handle avatar upload
                if (avatar != null && avatar.Length > 0)
                {
                    var uploadsFolder = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "uploads", "avatars");
                    Directory.CreateDirectory(uploadsFolder);
                    
                    var fileName = $"{user.Id}_{Guid.NewGuid()}{Path.GetExtension(avatar.FileName)}";
                    var filePath = Path.Combine(uploadsFolder, fileName);
                    
                    using (var stream = new FileStream(filePath, FileMode.Create))
                    {
                        await avatar.CopyToAsync(stream);
                    }
                    
                    user.PhotoUrl = $"/uploads/avatars/{fileName}";
                }

                // Update phone number if provided
                if (!string.IsNullOrEmpty(phoneNumber))
                {
                    user.PhoneNumber = phoneNumber;
                }

                user.UpdatedAt = DateTime.Now;
                var result = await _userManager.UpdateAsync(user);

                if (result.Succeeded)
                {
                    // Update role-specific info
                    if (roles != null && roles.Contains("CBGV"))
                    {
                        var staff = await _context.Staff.FirstOrDefaultAsync(s => s.UserId == user.Id);
                        if (staff != null)
                        {
                            if (!string.IsNullOrEmpty(phoneNumber))
                                staff.Phone = phoneNumber;
                            if (avatar != null && avatar.Length > 0)
                                staff.PhotoUrl = user.PhotoUrl;
                            staff.UpdatedAt = DateTime.Now;
                            _context.Staff.Update(staff);
                        }
                    }
                    else if (roles != null && roles.Contains("SinhVien"))
                    {
                        var student = await _context.Students.FirstOrDefaultAsync(s => s.UserId == user.Id);
                        if (student != null)
                        {
                            if (!string.IsNullOrEmpty(phoneNumber))
                                student.Phone = phoneNumber;
                            if (!string.IsNullOrEmpty(address))
                                student.Address = address;
                            if (avatar != null && avatar.Length > 0)
                                student.PhotoUrl = user.PhotoUrl;
                            student.UpdatedAt = DateTime.Now;
                            _context.Students.Update(student);
                        }
                    }

                    await _context.SaveChangesAsync();
                    await transaction.CommitAsync();

                    await _activityLogService.LogActivityAsync(user.Id, "UPDATE_PROFILE", "Cập nhật thông tin cá nhân");
                    TempData["Success"] = "Cập nhật thông tin thành công!";
                }
                else
                {
                    await transaction.RollbackAsync();
                    TempData["Error"] = "Có lỗi xảy ra khi cập nhật thông tin: " + string.Join(", ", result.Errors.Select(e => e.Description));
                }
            }
            catch (Exception ex)
            {
                await transaction.RollbackAsync();
                TempData["Error"] = "Có lỗi xảy ra khi cập nhật thông tin.";
                // Log the exception
            }

            return RedirectToAction("Profile");
        }

        public async Task<IActionResult> StaffList(string search, int? unitId, string position, string sort = "name_asc", int page = 1)
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null)
            {
                return RedirectToAction("Login", "Account");
            }

            var roles = await _userManager.GetRolesAsync(user);
            
            // Only CBGV and Admin can view staff list
            if (roles == null || (!roles.Contains("CBGV") && !roles.Contains("Admin")))
            {
                TempData["Error"] = "Bạn không có quyền truy cập danh sách CBGV.";
                return RedirectToAction("Dashboard");
            }

            await _activityLogService.LogActivityAsync(user.Id, "VIEW_STAFF_LIST", "Xem danh sách CBGV");

            ViewBag.UserRole = roles.FirstOrDefault() ?? "User";

            var query = _context.Staff.Include(s => s.Unit).AsQueryable();

            // Apply filters
            if (!string.IsNullOrEmpty(search))
            {
                query = query.Where(s => s.FullName.Contains(search) || 
                                        s.StaffCode.Contains(search) || 
                                        s.Position.Contains(search));
            }

            if (unitId.HasValue)
            {
                query = query.Where(s => s.UnitId == unitId.Value);
            }

            if (!string.IsNullOrEmpty(position))
            {
                query = query.Where(s => s.Position == position);
            }

            // Apply sorting
            query = sort switch
            {
                "name_desc" => query.OrderByDescending(s => s.FullName),
                "position_asc" => query.OrderBy(s => s.Position).ThenBy(s => s.FullName),
                "position_desc" => query.OrderByDescending(s => s.Position).ThenBy(s => s.FullName),
                "unit_asc" => query.OrderBy(s => s.Unit!.Name).ThenBy(s => s.FullName),
                "unit_desc" => query.OrderByDescending(s => s.Unit!.Name).ThenBy(s => s.FullName),
                _ => query.OrderBy(s => s.FullName) // default: name_asc
            };

            var totalCount = await query.CountAsync();
            var pageSize = 10;
            var staff = await query
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();

            // Set default avatars for staff without photos
            foreach (var s in staff)
            {
                if (string.IsNullOrEmpty(s.PhotoUrl))
                {
                    s.PhotoUrl = GetDefaultAvatar();
                }
            }

            // Get statistics for cards
            ViewBag.TotalStaff = totalCount;
            ViewBag.TeacherCount = await _context.Staff.CountAsync(s => s.Position.Contains("Giảng viên"));
            ViewBag.StaffCount = await _context.Staff.CountAsync(s => !s.Position.Contains("Giảng viên"));
            ViewBag.ActiveStaffCount = await _context.Staff.CountAsync(s => s.IsActive);

            ViewBag.Search = search;
            ViewBag.UnitId = unitId;
            ViewBag.Position = position;
            ViewBag.Sort = sort;
            ViewBag.CurrentPage = page;
            ViewBag.TotalPages = (int)Math.Ceiling(totalCount / (double)pageSize);
            ViewBag.Units = await _context.Units.OrderBy(u => u.Name).ToListAsync();
            ViewBag.Positions = await _context.Staff
                .Where(s => !string.IsNullOrEmpty(s.Position))
                .Select(s => s.Position)
                .Distinct()
                .OrderBy(p => p)
                .ToListAsync();

            return View(staff);
        }

        public async Task<IActionResult> StudentsList(string search, string className, string major, string sort = "name_asc", int page = 1)
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null)
            {
                return RedirectToAction("Login", "Account");
            }

            await _activityLogService.LogActivityAsync(user.Id, "VIEW_STUDENTS_LIST", "Xem danh sách sinh viên");

            var roles = await _userManager.GetRolesAsync(user);
            ViewBag.UserRole = roles?.FirstOrDefault() ?? "User";

            var query = _context.Students.AsQueryable();

            // Apply role-based filtering - BACKEND LOGIC FOR PERMISSION
            if (roles != null && roles.Contains("SinhVien"))
            {
                // Students can only see classmates - SAME CLASS RESTRICTION
                var currentStudent = await _context.Students.FirstOrDefaultAsync(s => s.UserId == user.Id);
                if (currentStudent != null)
                {
                    query = query.Where(s => s.ClassName == currentStudent.ClassName);
                }
                else
                {
                    // If student record not found, show empty list
                    query = query.Where(s => false);
                }
            }
            // CBGV can see all students - NO RESTRICTION

            // Apply search filters
            if (!string.IsNullOrEmpty(search))
            {
                query = query.Where(s => s.FullName.Contains(search) || 
                                        s.StudentCode.Contains(search) ||
                                        s.ClassName.Contains(search));
            }

            if (!string.IsNullOrEmpty(className))
            {
                query = query.Where(s => s.ClassName == className);
            }

            if (!string.IsNullOrEmpty(major))
            {
                query = query.Where(s => s.Major == major);
            }

            // Apply sorting
            query = sort switch
            {
                "name_desc" => query.OrderByDescending(s => s.FullName),
                "code_asc" => query.OrderBy(s => s.StudentCode),
                "code_desc" => query.OrderByDescending(s => s.StudentCode),
                "class_asc" => query.OrderBy(s => s.ClassName).ThenBy(s => s.FullName),
                "class_desc" => query.OrderByDescending(s => s.ClassName).ThenBy(s => s.FullName),
                _ => query.OrderBy(s => s.FullName) // default: name_asc
            };

            var totalCount = await query.CountAsync();
            var pageSize = 10;
            var students = await query
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();

            // Set default avatars for students without photos
            foreach (var s in students)
            {
                if (string.IsNullOrEmpty(s.PhotoUrl))
                {
                    s.PhotoUrl = GetDefaultAvatar();
                }
            }

            // Get statistics for cards
            ViewBag.TotalStudents = totalCount;
            ViewBag.ActiveStudents = await query.CountAsync(s => s.IsActive);
            ViewBag.TotalClasses = await query.Select(s => s.ClassName).Distinct().CountAsync();
            ViewBag.TotalYears = await query.Where(s => s.EnrollmentYear.HasValue)
                .Select(s => s.EnrollmentYear).Distinct().CountAsync();

            ViewBag.Search = search;
            ViewBag.ClassName = className;
            ViewBag.Major = major;
            ViewBag.Sort = sort;
            ViewBag.CurrentPage = page;
            ViewBag.TotalPages = (int)Math.Ceiling(totalCount / (double)pageSize);
            ViewBag.Classes = await query.Select(s => s.ClassName)
                .Distinct()
                .OrderBy(c => c)
                .ToListAsync();
            ViewBag.Majors = await query.Where(s => !string.IsNullOrEmpty(s.Major))
                .Select(s => s.Major)
                .Distinct()
                .OrderBy(m => m)
                .ToListAsync();

            return View(students);
        }

        public async Task<IActionResult> UnitsList(string search, string unitType, string sort = "name_asc", int page = 1)
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null)
            {
                return RedirectToAction("Login", "Account");
            }

            await _activityLogService.LogActivityAsync(user.Id, "VIEW_UNITS_LIST", "Xem danh sách đơn vị");

            var roles = await _userManager.GetRolesAsync(user);
            ViewBag.UserRole = roles?.FirstOrDefault() ?? "User";

            var query = _context.Units.Include(u => u.ParentUnit).AsQueryable();

            // Apply filters
            if (!string.IsNullOrEmpty(search))
            {
                query = query.Where(u => u.Name.Contains(search) || u.UnitCode.Contains(search));
            }

            if (!string.IsNullOrEmpty(unitType))
            {
                query = query.Where(u => u.UnitType == unitType);
            }

            // Apply sorting
            query = sort switch
            {
                "name_desc" => query.OrderByDescending(u => u.Name),
                "code_asc" => query.OrderBy(u => u.UnitCode),
                "code_desc" => query.OrderByDescending(u => u.UnitCode),
                "type_asc" => query.OrderBy(u => u.UnitType).ThenBy(u => u.Name),
                "type_desc" => query.OrderByDescending(u => u.UnitType).ThenBy(u => u.Name),
                _ => query.OrderBy(u => u.Name) // default: name_asc
            };

            var totalCount = await query.CountAsync();
            var pageSize = 12;
            var units = await query
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();

            ViewBag.Search = search;
            ViewBag.UnitType = unitType;
            ViewBag.Sort = sort;
            ViewBag.CurrentPage = page;
            ViewBag.TotalPages = (int)Math.Ceiling(totalCount / (double)pageSize);
            ViewBag.UnitTypes = await _context.Units
                .Where(u => !string.IsNullOrEmpty(u.UnitType))
                .Select(u => u.UnitType)
                .Distinct()
                .OrderBy(t => t)
                .ToListAsync();

            return View(units);
        }

        public async Task<IActionResult> UnitDetail(int id)
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null)
            {
                return RedirectToAction("Login", "Account");
            }

            await _activityLogService.LogActivityAsync(user.Id, "VIEW_UNIT_DETAIL", $"Xem chi tiết đơn vị ID: {id}", "Unit", id);

            var roles = await _userManager.GetRolesAsync(user);
            ViewBag.UserRole = roles?.FirstOrDefault() ?? "User";

            var unit = await _context.Units
                .Include(u => u.ParentUnit)
                .Include(u => u.ChildUnits)
                .Include(u => u.Staff)
                .FirstOrDefaultAsync(u => u.UnitId == id);

            if (unit == null)
            {
                return NotFound();
            }

            // Get child units with their staff count
            var childUnitsWithStats = await _context.Units
                .Where(u => u.ParentUnitId == id)
                .Select(u => new {
                    Unit = u,
                    StaffCount = _context.Staff.Count(s => s.UnitId == u.UnitId)
                })
                .ToListAsync();

            ViewBag.ChildUnitsWithStats = childUnitsWithStats;

            return View(unit);
        }

        public async Task<IActionResult> StaffDetail(int id)
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null)
            {
                return RedirectToAction("Login", "Account");
            }

            var roles = await _userManager.GetRolesAsync(user);
            
            // Only CBGV and Admin can view staff details
            if (roles == null || (!roles.Contains("CBGV") && !roles.Contains("Admin")))
            {
                TempData["Error"] = "Bạn không có quyền xem chi tiết CBGV.";
                return RedirectToAction("Dashboard");
            }

            await _activityLogService.LogActivityAsync(user.Id, "VIEW_STAFF_DETAIL", $"Xem chi tiết CBGV ID: {id}", "Staff", id);

            ViewBag.UserRole = roles.FirstOrDefault() ?? "User";

            var staff = await _context.Staff
                .Include(s => s.Unit)
                .FirstOrDefaultAsync(s => s.StaffId == id);

            if (staff == null)
            {
                return NotFound();
            }

            // Set default avatar if not available
            if (string.IsNullOrEmpty(staff.PhotoUrl))
            {
                staff.PhotoUrl = GetDefaultAvatar();
            }

            return View(staff);
        }

        public async Task<IActionResult> StudentDetail(int id)
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null)
            {
                return RedirectToAction("Login", "Account");
            }

            var roles = await _userManager.GetRolesAsync(user);
            ViewBag.UserRole = roles?.FirstOrDefault() ?? "User";

            var student = await _context.Students.FirstOrDefaultAsync(s => s.StudentId == id);
            if (student == null)
            {
                return NotFound();
            }

            // Check permissions - BACKEND PERMISSION LOGIC
            if (roles != null && roles.Contains("SinhVien"))
            {
                var currentStudent = await _context.Students.FirstOrDefaultAsync(s => s.UserId == user.Id);
                if (currentStudent == null || currentStudent.ClassName != student.ClassName)
                {
                    TempData["Error"] = "Bạn chỉ có thể xem thông tin sinh viên cùng lớp.";
                    return RedirectToAction("StudentsList");
                }
            }

            await _activityLogService.LogActivityAsync(user.Id, "VIEW_STUDENT_DETAIL", $"Xem chi tiết sinh viên ID: {id}", "Student", id);

            // Set default avatar if not available
            if (string.IsNullOrEmpty(student.PhotoUrl))
            {
                student.PhotoUrl = GetDefaultAvatar();
            }

            return View(student);
        }

        [HttpGet]
        public async Task<IActionResult> ChangePassword()
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null)
            {
                return RedirectToAction("Login", "Account");
            }

            var roles = await _userManager.GetRolesAsync(user);
            ViewBag.UserRole = roles?.FirstOrDefault() ?? "User";
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> ChangePassword(string currentPassword, string newPassword, string confirmPassword)
        {
            if (newPassword != confirmPassword)
            {
                ViewBag.Error = "Mật khẩu mới và xác nhận mật khẩu không khớp";
                return View();
            }

            var user = await _userManager.GetUserAsync(User);
            if (user == null)
            {
                return RedirectToAction("Login", "Account");
            }

            var result = await _userManager.ChangePasswordAsync(user, currentPassword, newPassword);

            if (result.Succeeded)
            {
                await _signInManager.RefreshSignInAsync(user);
                await _activityLogService.LogActivityAsync(user.Id, "CHANGE_PASSWORD", "Đổi mật khẩu thành công");
                ViewBag.Success = "Đổi mật khẩu thành công!";
                return View("Success");
            }

            ViewBag.Error = string.Join(", ", result.Errors.Select(e => e.Description));
            return View();
        }

        // Export Excel functionality
        public async Task<IActionResult> ExportStaffExcel()
        {
            var user = await _userManager.GetUserAsync(User);
            if (user != null)
            {
                await _activityLogService.LogActivityAsync(user.Id, "EXPORT_STAFF", "Xuất danh sách CBGV");
            }

            var staff = await _context.Staff.Include(s => s.Unit).ToListAsync();
            
            // Simple CSV export for now
            var csv = "STT,Mã CB,Họ tên,Chức vụ,Đơn vị,Email,Điện thoại\n";
            for (int i = 0; i < staff.Count; i++)
            {
                var s = staff[i];
                csv += $"{i + 1},{s.StaffCode},{s.FullName},{s.Position},{s.Unit?.Name},{s.Email},{s.Phone}\n";
            }

            var bytes = System.Text.Encoding.UTF8.GetBytes(csv);
            return File(bytes, "text/csv", "danh-sach-cbgv.csv");
        }

        public async Task<IActionResult> ExportStudentsExcel()
        {
            var user = await _userManager.GetUserAsync(User);
            if (user != null)
            {
                await _activityLogService.LogActivityAsync(user.Id, "EXPORT_STUDENTS", "Xuất danh sách sinh viên");
            }

            var students = await _context.Students.ToListAsync();
            
            var csv = "STT,Mã SV,Họ tên,Lớp,Email,Điện thoại,Địa chỉ\n";
            for (int i = 0; i < students.Count; i++)
            {
                var s = students[i];
                csv += $"{i + 1},{s.StudentCode},{s.FullName},{s.ClassName},{s.Email},{s.Phone},{s.Address}\n";
            }

            var bytes = System.Text.Encoding.UTF8.GetBytes(csv);
            return File(bytes, "text/csv", "danh-sach-sinh-vien.csv");
        }

        public async Task<IActionResult> ExportUnitsExcel()
        {
            var user = await _userManager.GetUserAsync(User);
            if (user != null)
            {
                await _activityLogService.LogActivityAsync(user.Id, "EXPORT_UNITS", "Xuất danh sách đơn vị");
            }

            var units = await _context.Units
                .Include(u => u.ParentUnit)
                .Include(u => u.Staff)
                .OrderBy(u => u.Name)
                .ToListAsync();
            
            var csv = "STT,Mã đơn vị,Tên đơn vị,Loại,Đơn vị cha,Địa chỉ,Điện thoại,Email,Số CBGV,Trạng thái\n";
            for (int i = 0; i < units.Count; i++)
            {
                var u = units[i];
                csv += $"{i + 1},{u.UnitCode},{u.Name},{u.UnitType},{u.ParentUnit?.Name},{u.Address},{u.Phone},{u.Email},{u.Staff.Count},{(u.IsActive ? "Hoạt động" : "Tạm dừng")}\n";
            }

            var bytes = System.Text.Encoding.UTF8.GetBytes(csv);
            return File(bytes, "text/csv", "danh-sach-don-vi.csv");
        }
    }
}
