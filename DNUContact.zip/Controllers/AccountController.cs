using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using DNUContact.Models;
using DNUContact.Services;
using DNUContact.Data;
using System.Text.RegularExpressions;
using System.Linq;

namespace DNUContact.Controllers
{
    public class AccountController : Controller
    {
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly SignInManager<ApplicationUser> _signInManager;
        private readonly RoleManager<IdentityRole> _roleManager;
        private readonly IEmailService _emailService;
        private readonly ApplicationDbContext _context;
        private readonly IActivityLogService _activityLogService;

        public AccountController(
            UserManager<ApplicationUser> userManager, 
            SignInManager<ApplicationUser> signInManager,
            RoleManager<IdentityRole> roleManager,
            IEmailService emailService,
            ApplicationDbContext context,
            IActivityLogService activityLogService)
        {
            _userManager = userManager;
            _signInManager = signInManager;
            _roleManager = roleManager;
            _emailService = emailService;
            _context = context;
            _activityLogService = activityLogService;
        }

        [HttpGet]
        public IActionResult Register()
        {
            if (User.Identity?.IsAuthenticated == true)
            {
                return RedirectToAction("Dashboard", "User");
            }
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Register(string fullName, string email, string password, string confirmPassword, string? staffCode, string? studentCode)
        {
            // Validation
            if (string.IsNullOrEmpty(fullName) || string.IsNullOrEmpty(email) || string.IsNullOrEmpty(password))
            {
                ViewBag.Error = "Vui lòng nhập đầy đủ thông tin bắt buộc";
                return View();
            }

            if (password != confirmPassword)
            {
                ViewBag.Error = "Mật khẩu xác nhận không khớp";
                return View();
            }

            // Email domain validation
            string role;
            if (email.EndsWith("@dnu.edu.vn", StringComparison.OrdinalIgnoreCase))
            {
                role = "CBGV";
            }
            else if (email.EndsWith("@e.dnu.edu.vn", StringComparison.OrdinalIgnoreCase))
            {
                role = "SinhVien";
            }
            else
            {
                ViewBag.Error = "Email phải sử dụng domain @dnu.edu.vn (CBGV) hoặc @e.dnu.edu.vn (Sinh viên)";
                return View();
            }

            // Check if user already exists
            var existingUser = await _userManager.FindByEmailAsync(email);
            if (existingUser != null)
            {
                ViewBag.Error = "Email này đã được đăng ký";
                return View();
            }

            // Create user with admin approval required
            var user = new ApplicationUser
            {
                UserName = email,
                Email = email,
                FullName = fullName,
                IsEmailVerified = false, // Requires admin approval
                IsActive = false, // Inactive until admin approves
                CreatedAt = DateTime.Now,
                PhotoUrl = "/images/default-avatar.png"
            };

            var result = await _userManager.CreateAsync(user, password);

            if (result.Succeeded)
            {
                // Add role
                await _userManager.AddToRoleAsync(user, role);

                // Log activity
                await _activityLogService.LogActivityAsync(user.Id, "REGISTER_PENDING", $"Đăng ký tài khoản mới chờ duyệt với role {role}");

                // Notify admin about new registration (optional)
                // await _emailService.NotifyAdminNewRegistrationAsync(user.Email, user.FullName, role);

                ViewBag.Success = "Đăng ký thành công! Tài khoản của bạn đang chờ admin duyệt.";
                ViewBag.Email = user.Email;
                return View("RegisterPending");
            }

            ViewBag.Error = string.Join(", ", result.Errors.Select(e => e.Description));
            return View();
        }

        [HttpGet]
        public IActionResult RegisterPending()
        {
            return View();
        }

        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Login(string email, string password, bool rememberMe = false)
        {
            if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(password))
            {
                ViewBag.Error = "Vui lòng nhập đầy đủ email và mật khẩu";
                return View();
            }

            var user = await _userManager.FindByEmailAsync(email);
            if (user == null)
            {
                ViewBag.Error = "Email hoặc mật khẩu không chính xác";
                return View();
            }

            if (!user.IsActive)
            {
                ViewBag.Error = "Tài khoản của bạn chưa được kích hoạt hoặc đang chờ admin duyệt";
                return View();
            }

            var result = await _signInManager.PasswordSignInAsync(user, password, rememberMe, lockoutOnFailure: true);

            if (result.Succeeded)
            {
                await _activityLogService.LogActivityAsync(user.Id, "LOGIN", "Đăng nhập thành công");

                var roles = await _userManager.GetRolesAsync(user);
                if (roles.Contains("Admin"))
                {
                    return RedirectToAction("Dashboard", "Admin");
                }
                return RedirectToAction("Dashboard", "User");
            }

            if (result.IsLockedOut)
            {
                ViewBag.Error = "Tài khoản đã bị khóa do đăng nhập sai quá nhiều lần";
                return View();
            }

            ViewBag.Error = "Email hoặc mật khẩu không chính xác";
            return View();
        }

        [HttpGet]
        public IActionResult ForgotPassword()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> ForgotPassword(string email)
        {
            if (string.IsNullOrEmpty(email))
            {
                ViewBag.Error = "Vui lòng nhập email";
                return View();
            }

            var user = await _userManager.FindByEmailAsync(email);
            if (user != null && user.IsActive)
            {
                var token = await _userManager.GeneratePasswordResetTokenAsync(user);
                var resetLink = Url.Action("ResetPassword", "Account", 
                    new { userId = user.Id, token = token }, Request.Scheme);

                if (!string.IsNullOrEmpty(user.Email) && !string.IsNullOrEmpty(resetLink))
                {
                    await _emailService.SendPasswordResetAsync(user.Email, resetLink);
                }
                await _activityLogService.LogActivityAsync(user.Id, "PASSWORD_RESET_REQUEST", "Yêu cầu đặt lại mật khẩu");
            }

            // Always show success message for security
            ViewBag.Success = "Nếu email tồn tại trong hệ thống, chúng tôi đã gửi link đặt lại mật khẩu.";
            return View();
        }

        [HttpGet]
        public IActionResult ResetPassword(string userId, string token)
        {
            if (string.IsNullOrEmpty(userId) || string.IsNullOrEmpty(token))
            {
                return BadRequest("Invalid password reset request");
            }

            ViewBag.UserId = userId;
            ViewBag.Token = token;
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> ResetPassword(string userId, string token, string password, string confirmPassword)
        {
            if (string.IsNullOrEmpty(userId) || string.IsNullOrEmpty(token))
            {
                ViewBag.Error = "Invalid password reset request";
                return View();
            }

            if (password != confirmPassword)
            {
                ViewBag.Error = "Mật khẩu xác nhận không khớp";
                ViewBag.UserId = userId;
                ViewBag.Token = token;
                return View();
            }

            var user = await _userManager.FindByIdAsync(userId);
            if (user == null)
            {
                ViewBag.Error = "User not found";
                return View();
            }

            var result = await _userManager.ResetPasswordAsync(user, token, password);
            if (result.Succeeded)
            {
                await _activityLogService.LogActivityAsync(user.Id, "PASSWORD_RESET", "Đặt lại mật khẩu thành công");
                ViewBag.Success = "Mật khẩu đã được đặt lại thành công! Bạn có thể đăng nhập ngay bây giờ.";
                return View("ResetPasswordSuccess");
            }

            ViewBag.Error = string.Join(", ", result.Errors.Select(e => e.Description));
            ViewBag.UserId = userId;
            ViewBag.Token = token;
            return View();
        }

        public async Task<IActionResult> Logout()
        {
            var user = await _userManager.GetUserAsync(User);
            if (user != null)
            {
                await _activityLogService.LogActivityAsync(user.Id, "LOGOUT", "Đăng xuất");
            }

            await _signInManager.SignOutAsync();
            return RedirectToAction("Login");
        }
    }
}
