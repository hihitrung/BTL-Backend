using System.ComponentModel.DataAnnotations;

namespace DNUContact.ViewModels
{
    public class ProfileUpdateViewModel
    {
        [Phone(ErrorMessage = "Số điện thoại không hợp lệ")]
        [StringLength(20, ErrorMessage = "Số điện thoại không được quá 20 ký tự")]
        public string? PhoneNumber { get; set; }

        [StringLength(500, ErrorMessage = "Địa chỉ không được quá 500 ký tự")]
        public string? Address { get; set; }

        [Display(Name = "Ảnh đại diện")]
        public IFormFile? Avatar { get; set; }
    }
}
