-- Insert default roles
INSERT INTO Roles (RoleName, Description) VALUES 
('Admin', 'Quản trị viên hệ thống'),
('CBGV', 'Cán bộ giảng viên'),
('SinhVien', 'Sinh viên');