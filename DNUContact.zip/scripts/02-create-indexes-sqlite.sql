-- Fixed indexes for actual database schema

-- AspNetUsers table indexes (thay vì Users)
CREATE INDEX IF NOT EXISTS IX_AspNetUsers_Email ON AspNetUsers(Email);
CREATE INDEX IF NOT EXISTS IX_AspNetUsers_IsActive ON AspNetUsers(LockoutEnabled);

-- Units table indexes
CREATE INDEX IF NOT EXISTS IX_Units_UnitCode ON Units(UnitCode);
CREATE INDEX IF NOT EXISTS IX_Units_Name ON Units(Name);
CREATE INDEX IF NOT EXISTS IX_Units_UnitType ON Units(UnitType);
CREATE INDEX IF NOT EXISTS IX_Units_ParentUnitId ON Units(ParentUnitId);

-- Staff table indexes
CREATE INDEX IF NOT EXISTS IX_Staff_StaffCode ON Staff(StaffCode);
CREATE INDEX IF NOT EXISTS IX_Staff_FullName ON Staff(FullName);
CREATE INDEX IF NOT EXISTS IX_Staff_Position ON Staff(Position);
CREATE INDEX IF NOT EXISTS IX_Staff_UnitId ON Staff(UnitId);
CREATE INDEX IF NOT EXISTS IX_Staff_UserId ON Staff(UserId);
CREATE INDEX IF NOT EXISTS IX_Staff_Email ON Staff(Email);

-- Students table indexes
CREATE INDEX IF NOT EXISTS IX_Students_StudentCode ON Students(StudentCode);
CREATE INDEX IF NOT EXISTS IX_Students_FullName ON Students(FullName);
CREATE INDEX IF NOT EXISTS IX_Students_ClassName ON Students(ClassName);
CREATE INDEX IF NOT EXISTS IX_Students_Major ON Students(Major);
CREATE INDEX IF NOT EXISTS IX_Students_UserId ON Students(UserId);
CREATE INDEX IF NOT EXISTS IX_Students_Email ON Students(Email);
CREATE INDEX IF NOT EXISTS IX_Students_UnitId ON Students(UnitId);

-- Roles table indexes (custom Roles table)
CREATE INDEX IF NOT EXISTS IX_Roles_RoleName ON Roles(RoleName);
CREATE INDEX IF NOT EXISTS IX_Roles_IsActive ON Roles(IsActive);
