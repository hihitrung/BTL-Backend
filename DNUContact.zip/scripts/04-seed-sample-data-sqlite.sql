-- Sample data for testing DNUContact system

-- Insert sample units
-- Complete INSERT script with all required columns
INSERT INTO Units (UnitCode, Name, UnitType, Address, Phone, Email, IsActive, CreatedAt) VALUES
                                                                                             ('DNU', 'Đại học Đông Á', 'Trường', '33 Xô Viết Nghệ Tĩnh, Hải Châu, Đà Nẵng', '0236.3650403', 'info@donga.edu.vn', 1, datetime('now')),
                                                                                             ('CNTT', 'Khoa Công nghệ Thông tin', 'Khoa', '33 Xô Viết Nghệ Tĩnh, Hải Châu, Đà Nẵng', '0236.3650404', 'cntt@donga.edu.vn', 1, datetime('now')),
                                                                                             ('KT', 'Khoa Kinh tế', 'Khoa', '33 Xô Viết Nghệ Tĩnh, Hải Châu, Đà Nẵng', '0236.3650405', 'kt@donga.edu.vn', 1, datetime('now')),
                                                                                             ('NN', 'Khoa Ngoại ngữ', 'Khoa', '33 Xô Viết Nghệ Tĩnh, Hải Châu, Đà Nẵng', '0236.3650406', 'nn@donga.edu.vn', 1, datetime('now'));

-- Update parent-child relationships
UPDATE Units SET ParentUnitId = 1 WHERE UnitCode IN ('CNTT', 'KT', 'NN');
