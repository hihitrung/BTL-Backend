-- Update existing data to change "Đại học Đông Á" to "Khoa Dược"
UPDATE Units 
SET Name = 'Khoa Dược', 
    UnitCode = 'DUOC',
    UnitType = 'Khoa',
    UpdatedAt = datetime('now')
WHERE UnitCode = 'DNU';

-- Add more sample units
INSERT INTO Units (UnitCode, Name, UnitType, Address, Phone, Email, IsActive, CreatedAt) VALUES
('CNSH', 'Khoa Công nghệ sinh học', 'Khoa', 'Hà Nội', '024-12345680', 'cnsh@dnu.edu.vn', 1, datetime('now')),
('YHCT', 'Khoa Y học cổ truyền', 'Khoa', 'Hà Nội', '024-12345681', 'yhct@dnu.edu.vn', 1, datetime('now')),
('QLDD', 'Khoa Quản lý dược', 'Khoa', 'Hà Nội', '024-12345682', 'qldd@dnu.edu.vn', 1, datetime('now')),
('HCHP', 'Bộ môn Hóa chế phẩm', 'Bộ môn', 'Hà Nội', '024-12345683', 'hchp@dnu.edu.vn', 1, datetime('now'));

-- Update existing staff to belong to units
UPDATE Staff 
SET UnitId = (SELECT UnitId FROM Units WHERE UnitCode = 'DUOC' LIMIT 1),
    UpdatedAt = datetime('now')
WHERE UnitId IS NULL OR UnitId = 1;

-- Update existing students to belong to units
UPDATE Students
SET UnitId = (SELECT UnitId FROM Units WHERE UnitCode = 'DUOC' LIMIT 1),
    UpdatedAt = datetime('now')
WHERE UnitId IS NULL;
