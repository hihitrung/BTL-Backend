-- SQLite Database Structure for DNUContact

-- Create Roles table
CREATE TABLE Roles (
    RoleId INTEGER PRIMARY KEY AUTOINCREMENT,
    RoleName TEXT NOT NULL UNIQUE,
    Description TEXT,
    IsActive INTEGER NOT NULL DEFAULT 1,
    CreatedAt TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Create Users table
CREATE TABLE Users (
    UserId TEXT PRIMARY KEY,
    Email TEXT NOT NULL UNIQUE,
    PasswordHash TEXT NOT NULL,
    FullName TEXT,
    PhotoUrl TEXT,
    PhoneNumber TEXT,
    RoleId INTEGER,
    IsEmailVerified INTEGER NOT NULL DEFAULT 0,
    IsActive INTEGER NOT NULL DEFAULT 1,
    CreatedAt TEXT NOT NULL DEFAULT (datetime('now')),
    UpdatedAt TEXT,
    FOREIGN KEY (RoleId) REFERENCES Roles(RoleId) ON DELETE SET NULL
);

-- Create Units table
CREATE TABLE Units (
    UnitId INTEGER PRIMARY KEY AUTOINCREMENT,
    UnitCode TEXT NOT NULL UNIQUE,
    Name TEXT NOT NULL,
    Address TEXT,
    LogoUrl TEXT,
    Phone TEXT,
    Email TEXT,
    Fax TEXT,
    ParentUnitId INTEGER,
    UnitType TEXT,
    IsActive INTEGER NOT NULL DEFAULT 1,
    CreatedAt TEXT NOT NULL DEFAULT (datetime('now')),
    UpdatedAt TEXT,
    FOREIGN KEY (ParentUnitId) REFERENCES Units(UnitId)
);

-- Create Staff table
CREATE TABLE Staff (
    StaffId INTEGER PRIMARY KEY AUTOINCREMENT,
    StaffCode TEXT NOT NULL UNIQUE,
    FullName TEXT NOT NULL,
    Position TEXT,
    Phone TEXT,
    Email TEXT UNIQUE,
    PhotoUrl TEXT,
    UnitId INTEGER,
    UserId TEXT NOT NULL UNIQUE,
    IsActive INTEGER NOT NULL DEFAULT 1,
    CreatedAt TEXT NOT NULL DEFAULT (datetime('now')),
    UpdatedAt TEXT,
    FOREIGN KEY (UnitId) REFERENCES Units(UnitId) ON DELETE SET NULL,
    FOREIGN KEY (UserId) REFERENCES Users(UserId) ON DELETE CASCADE
);

-- Create Students table
CREATE TABLE Students (
    StudentId INTEGER PRIMARY KEY AUTOINCREMENT,
    StudentCode TEXT NOT NULL UNIQUE,
    FullName TEXT NOT NULL,
    PhotoUrl TEXT,
    Phone TEXT,
    Email TEXT UNIQUE,
    Address TEXT,
    ClassName TEXT,
    Major TEXT,
    EnrollmentYear INTEGER,
    UnitId INTEGER,
    UserId TEXT NOT NULL UNIQUE,
    IsActive INTEGER NOT NULL DEFAULT 1,
    CreatedAt TEXT NOT NULL DEFAULT (datetime('now')),
    UpdatedAt TEXT,
    FOREIGN KEY (UnitId) REFERENCES Units(UnitId) ON DELETE SET NULL,
    FOREIGN KEY (UserId) REFERENCES Users(UserId) ON DELETE CASCADE
);
